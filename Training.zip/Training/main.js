// $(document).ready(function () {
//     setTimeout( function(){$("#card1").css("opacity", "100%");}, 1000)
//     setTimeout( function(){$("#card2").css("opacity", "100%");}, 1500)
//     setTimeout( function(){$("#card3").css("opacity", "100%");}, 2000)
//     setTimeout( function(){$("#card4").css("opacity", "100%");}, 2500)
//     setTimeout( function(){$("#card5").css("opacity", "100%");}, 3000)
//     setTimeout( function(){$("#card6").css("opacity", "100%");}, 3500)
// });
